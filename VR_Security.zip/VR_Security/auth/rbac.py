from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

# Create a blueprint for RBAC routes
rbac_blueprint = Blueprint('rbac', __name__)

# Permissions dictionary defines what actions each role can perform
permissions = {
    "Admin": ["read", "write", "delete"],
    "Moderator": ["read", "write"],
    "User": ["read"]
}

@rbac_blueprint.route('/resource/<action>', methods=['GET'])
@jwt_required()
def access_resource(action):
    try:
        # Get the identity from the JWT token
        identity = get_jwt_identity()

        # Retrieve role from the JWT token, fallback to 'User' if no role is present
        role = identity.get("role", "User")

        # Check if the requested action is within the permissions for the user's role
        if action in permissions.get(role, []):
            return jsonify({"message": f"Access granted for {action} action."}), 200
        else:
            return jsonify({"error": "Access denied"}), 403

    except Exception as e:
        # In case of an error, return a generic error message
        return jsonify({"error": "An error occurred while processing the request", "message": str(e)}), 500
