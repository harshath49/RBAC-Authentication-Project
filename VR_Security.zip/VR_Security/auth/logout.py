from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from auth.jwt_instance import jwt  # Ensure the jwt instance is imported here

logout_blueprint = Blueprint('logout', __name__)

blacklist = set()

@logout_blueprint.route('/auth/logout', methods=['POST'])
@jwt_required()
def logout():
    jti = get_jwt()["jti"]
    blacklist.add(jti)  # Add the JWT to the blacklist
    return jsonify({"message": "Successfully logged out"}), 200

@jwt.token_in_blocklist_loader
def check_if_token_in_blacklist(jwt_header, jwt_payload):
    return jwt_payload["jti"] in blacklist  # Check if token is in the blacklist
