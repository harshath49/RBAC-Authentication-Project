from flask import Flask
from auth.jwt_instance import jwt
from auth.register import register_blueprint
from auth.login import login_blueprint
from auth.logout import logout_blueprint
from auth.rbac import rbac_blueprint

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'secret'


jwt.init_app(app)

app.register_blueprint(register_blueprint)
app.register_blueprint(login_blueprint)
app.register_blueprint(logout_blueprint, url_prefix='/auth')
app.register_blueprint(rbac_blueprint)

for rule in app.url_map.iter_rules():
    print(f"Endpoint: {rule.endpoint}, URL: {rule}")

if __name__ == "__main__":
    app.run(debug=True)
