import sqlite3

def initialize_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')

    # Predefined roles
    roles = ['Admin', 'Moderator', 'User']
    for role in roles:
        cursor.execute('''
            INSERT OR IGNORE INTO users (username, password, role)
            VALUES (?, ?, ?)
        ''', (role.lower(), '', role))

    conn.commit()
    conn.close()

if __name__ == "__main__":
    initialize_db()
